# PFC Submission Draft — Sections 1, 2, 3, 5

Draft text for your submission document. Word counts are close to the assignment's
targets but adjust once you drop in real screenshots and transcripts. Everything in
the Pipeline in Action section marked "[PLACEHOLDER]" needs your actual evidence
before submission; the shape and wording around it can stay.

---

## Your Organisation (≈200 words)

Policy Fit Checker (PFC) is a fictional insurance discovery platform, built on the
model of Booking.com or Airbnb: instead of browsing hotels or listings, a customer
describes their life circumstances and is matched to the insurance policy and provider
that genuinely fits them.

The business challenge is that insurance comparison today is fragmented and poorly
personalised. A 22-year-old student, a self-employed contractor, a new parent, and a
72-year-old managing a chronic condition all have fundamentally different insurance
needs, but existing comparison tools mostly sort the same catalog by price for everyone.
The result is under-insurance, over-insurance, and low trust in the recommendation
process itself, because nothing explains why a suggested policy actually suits the
person receiving it.

This challenge benefits from an agentic approach because matching a person to the right
policy is not a single task, it is a chain of distinct ones: understanding who the
customer actually is, researching what genuinely fits from a live catalog, designing a
personalised and explainable shortlist, building a working comparison experience, and
communicating the result in language the customer will trust. Five specialised agents,
each owning one stage and handing off to the next, mirror how a real insurance
brokerage team works, and produce a result no single generalist model call could
reliably reproduce.

*(≈195 words)*

---

## Agent Designs (≈500 words)

Five agents, each with a distinct name, role, and full system prompt. Full persona
files (`NadiaKestrel.md`, `MiloFerreira.md`, `PriyaAshworth.md`, `SashaLindqvist.md`,
`CallumDoyle.md`) are included in the code zip; the condensed system prompts below are
what is actually loaded at runtime for each agent's turn in the pipeline.

**1. Nadia Kestrel — Researcher**
*System prompt (condensed):* "You are Nadia Kestrel, PFC's researcher. Given a customer
profile, query the live PFC policy catalog and return only policies that genuinely fit:
correct age band, life-stage tag, and budget range. Cite every claim with its exact
policy_id. If nothing fits well, say so plainly and explain the gap rather than forcing
a weak match. Never invent a premium, exclusion, or coverage figure. Output a structured
research brief for the Designer: profile summary, eligible policies with reasoning, and
open questions."
*Produces:* a structured research brief (JSON plus plain-language summary).

**2. Milo Ferreira — Designer**
*System prompt (condensed):* "You are Milo Ferreira, PFC's designer. Given Nadia's
research brief, decide which two to four policies to present, in what order, and what
one-line reason best explains the fit for this specific customer. Prioritise clarity
over completeness: cut anything that does not change the customer's decision. Write in
plain language, never insurance jargon. Output a shortlist specification for the Maker:
which policies, in what order, with what explanation text."
*Produces:* a shortlist specification (which policies, ordering, explanation copy).

**3. Priya Ashworth — Maker**
*System prompt (condensed):* "You are Priya Ashworth, PFC's maker. Given Milo's
shortlist specification, render it as the actual result the customer sees, pulling
every figure live from the same catalog query Nadia used, never from a cached or
hardcoded value. Confirm each policy_id still resolves to real catalog data before
rendering it. Output the final rendered result plus a short technical note confirming
the data was fetched live."
*Produces:* the working, rendered shortlist plus a data-provenance note.

**4. Sasha Lindqvist — Communicator**
*System prompt (condensed):* "You are Sasha Lindqvist, PFC's communicator. Given the
rendered shortlist, write the surrounding customer-facing copy: the framing above the
results, and, if the match is weak or empty, an honest message explaining why. Never
promise an outcome the match cannot support. Ground every claim in the actual data
Priya rendered, not in generic marketing language. Output final customer-facing copy."
*Produces:* final customer-facing copy for the results screen.

**5. Callum Doyle — Manager**
*System prompt (condensed):* "You are Callum Doyle, PFC's manager. Review the outputs
from Nadia, Milo, Priya, and Sasha in sequence. Confirm each handoff is coherent with
the one before it and flag any mismatch before it reaches the customer. Produce a short
executive summary of the run: what the customer asked for, what was found, and any
gaps or caveats worth noting." 
*Produces:* an executive summary and quality-gate confirmation for the run.

**How the personalities differ:** Nadia is evidence-first and comfortable saying "I do
not know," grounded entirely in the live catalog. Milo is a simplifier, focused on
what changes a decision rather than what is merely available. Priya is literal and
technical, concerned only with whether the data is genuinely live and correctly
rendered. Sasha is customer-facing and trust-first, translating technical accuracy into
language a worried customer will believe. Callum is the only agent who does not
produce customer-facing content at all: his output is a check on the other four,
never a replacement for their work.

*(≈505 words)*

---

## The Pipeline in Action (≈300 words plus evidence)

Work flows through PFC as a strict, one-directional chain: Researcher, Designer, Maker,
Communicator, Manager. Each agent receives only the previous agent's structured output,
never the customer's raw input directly (except Nadia, who receives it first), which
keeps every handoff explicit and inspectable rather than implicit context sharing.

A run begins when a customer profile is submitted through the intake flow. Nadia
queries the live Google Sheet policy catalog at that moment, filters by age band,
life-stage tag, and budget, and returns a structured research brief naming eligible
policies by `policy_id`, or explicitly naming a coverage gap if nothing fits well. Milo
receives that brief and decides which two to four policies to surface and in what
order, producing a shortlist specification with plain-language reasoning attached to
each. Priya takes that specification and renders the actual result the customer sees,
re-confirming each policy_id against the same live catalog rather than trusting Milo's
snapshot, which is the point in the pipeline where the technical live-data requirement
is most directly demonstrated. Sasha writes the customer-facing framing around Priya's
rendered result, and Callum reviews the full chain, producing a short executive summary
confirming the handoff was coherent end to end.

[PLACEHOLDER: insert 4 to 5 screenshots here, one per pipeline stage, showing: the
intake form submitted, the pipeline diagram mid-run with the active node highlighted,
Nadia's raw research brief output, Milo's shortlist specification, and the final
rendered result with Sasha's copy. Insert one transcript excerpt showing the actual
JSON or text handed from one agent to the next, not a paraphrase, to prove the handoff
is real.]

[PLACEHOLDER: note the live GitHub Pages URL here and confirm the run shown in the
screenshots was captured from that deployed URL, not localhost.]

*(≈250 words, excluding placeholders)*

---

## Regulatory and Ethical Considerations (≈200 words)

PFC processes profile data (age, health status, dependants, income sensitivity) that
GDPR treats as requiring particular care; some of it, such as health status, is special
category data under Article 9, needing explicit consent and a clear lawful basis before
any matching runs. Data minimisation applies directly: PFC should ask only what changes
a match, retain profiles no longer than needed to show a result, and support deletion
on request.

Under the EU AI Act, the closest classification question is whether PFC counts as a
system for "risk assessment and pricing in relation to natural persons in the case of
life and health insurance" under Annex III, point 5(c), which is explicitly high-risk.
PFC does not itself price or underwrite; it recommends from existing third-party
products, which places it closer to the Article 50 transparency-duty tier (informing
customers plainly that they are interacting with an AI system) rather than full
Annex III obligations, but the boundary is genuinely close given the subject matter,
and a real deployment would need a documented Article 6(3)/(4) assessment to justify
sitting outside Annex III rather than assuming it.

Customer trust depends on this being visible, not assumed: showing why a policy was
matched, disclosing the AI's role plainly, and being honest when nothing fits well are
what would make a nervous customer trust PFC over a black-box competitor.

*(≈200 words)*
