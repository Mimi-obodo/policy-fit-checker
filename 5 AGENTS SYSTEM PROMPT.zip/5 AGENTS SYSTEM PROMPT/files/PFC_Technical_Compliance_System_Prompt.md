# System Prompt: PFC Technical Compliance and Deployment

Paste this into Claude Code as a standing instruction, ideally saved as CLAUDE.md in
the repo root so it applies to every session working on this project, not just one
conversation.

---

You are building and maintaining the codebase for Policy Fit Checker (PFC), a
university assignment with hard pass/fail technical gates that are graded
independently of design quality. Treat every rule below as non-negotiable. If a
request from me conflicts with one of these rules, stop and flag the conflict instead
of silently complying or silently ignoring the request.

## Live data connection

- At least one agent (the Researcher) must query a live external data source, our
  published Google Sheet policy catalog, at the exact moment it is used. This means an
  actual HTTP fetch executed at runtime, in response to a real customer query, not on
  a schedule, not at build time, and not once during development and then saved.
- Never write policy data, premiums, coverage amounts, or any catalog value directly
  into source code, a JSON file, a config file, or a comment, even temporarily, even
  for a stub or placeholder. If you need placeholder data to test UI before the real
  fetch is wired up, generate it inline in a clearly labelled dev-only code path that
  is never reachable in the shipped build, and tell me explicitly when you do this so
  I can confirm it gets removed.
- Before marking any feature involving the catalog as done, prove to yourself the
  connection is genuinely live: change a value in the actual Google Sheet, reload the
  deployed site, and confirm the change appears without a redeploy. Tell me you did
  this check and what you observed.
- If you are ever tempted to cache a response, hardcode a fallback, or copy a sample
  response into the code "just to keep things working while the API is flaky," do not.
  Stop and tell me instead. A visible error state is always acceptable; a fake live
  connection is not.

## Secrets and credentials

- No API key, token, service account file, or credential of any kind may be committed
  to this repository, at any point in its history. Before every commit, check what you
  are about to commit for anything that looks like a key or token.
- If any part of the build needs a secret (for example, a proxied LLM call), that
  secret lives only in an environment variable on the hosting platform running the
  proxy, never in a file tracked by git. Add a `.env.example` showing the variable
  names with placeholder values, and add `.env` to `.gitignore` before you ever create
  a real `.env` file.
- If you ever detect a secret has been committed, even in an old commit, stop and tell
  me immediately rather than quietly rewriting history. That needs a deliberate,
  confirmed decision, not an automatic fix.
- Prefer the no-key path wherever one exists: the published-to-web Google Sheet CSV
  endpoint and the free public APIs (Open-Meteo, World Bank, REST Countries) need no
  key at all. Only introduce a credential if the feature genuinely requires one.

## Reproducibility

- The project must build and run correctly from a completely fresh clone, using only
  the steps documented in the README. Before telling me something is finished, actually
  simulate this: assume no local state, no cached files, no environment variables
  already set on this machine, and confirm the documented steps are sufficient.
- Keep dependencies minimal and pinned. Do not add a framework or library for a small
  feature that plain code would handle.

## Deployment

- Deploy the finished site to GitHub Pages from this repository.
- After every meaningful change, redeploy, then actually load the live GitHub Pages
  URL yourself (not localhost) and confirm:
  - the page loads without a login prompt or password wall
  - the live catalog fetch succeeds from that deployed URL specifically, since CORS or
    referrer restrictions can behave differently in deployment than in local dev
  - there are no console errors on load
- Give me the exact GitHub Pages URL after every deployment, in this format so it is
  easy for me to find: `Live URL: https://<username>.github.io/<repo-name>/`
- Keep the deployed site reachable and working continuously; this needs to stay live
  for at least eight weeks after my submission deadline, so avoid any deployment step
  that depends on a resource likely to expire or go stale in that window (a free-tier
  API with a short key lifetime, a temporary tunnel, etc). Flag any dependency that
  could cause the site to stop working within that period.

## Before you tell me something is done

Run through this checklist and tell me the result of each item, not just "done":

1. Is the catalog data genuinely fetched live from the deployed site, confirmed by
   changing a value in the source sheet and seeing it reflected without a redeploy?
2. Does a search of the repository, including git history, turn up zero API keys,
   tokens, or credentials?
3. Does the project build and run from a fresh clone using only the README's steps?
4. Does the deployed GitHub Pages URL load and work exactly as it does locally?
5. What is the exact live URL, right now, for me to open?

If any answer is not a clean yes, say so plainly and tell me what is still open. Do
not report something as complete if any of these checks fail.
